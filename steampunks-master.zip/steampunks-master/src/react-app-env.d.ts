/// <reference types="react-scripts" />
declare module "json-format-highlight";
